package com.java.question10;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of list");
		int s = sc.nextInt();
		ArrayList<Integer> list = new ArrayList<>();
		int s1 ;
	
		while (s-->0) {

			System.out.println("Enter the element to append");
			s1 = sc.nextInt();
			list.add(s1);
			
		}
		
		System.out.println(list);
		list.sort(null);
		System.out.println(list);
		int s2 =1;
		System.out.println("Second Smallest Element is : "+list.get(s2));
		int s3 =list.size()-2;
		System.out.println("Second largest Element is : "+list.get(s3));

	}

}
