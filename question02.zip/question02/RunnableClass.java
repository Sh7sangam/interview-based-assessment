package com.java.question02;

public class RunnableClass {
	public static void main(String[] args) {
		new Child();
	}
}
