package com.java.question02;

public class Parent {
	
	public Parent() {
		System.out.println("Parent class constructor called");
	}
}

class Child extends Parent{
	public Child() {
		System.out.println("Child class constructor called");
	}
}
