package com.java.question06;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Test1 {

	public static void main(String[] args) {
		
		ArrayList <Integer> al = new ArrayList<>();
		al.add(20);
		al.add(0);
		al.add(10);
		al.add(5);
		al.add(15);
		al.add(25);
		
		System.out.println(al);
		
		List<Integer> filter = al.stream().filter(i -> i % 2 ==0).collect(Collectors.toList());
		System.out.println(filter);
		List<Integer> map = al.stream().map(i->i*2).collect(Collectors.toList());
		System.out.println(map);
		List<Integer> sort = al.stream().sorted().collect(Collectors.toList());
		System.out.println(sort);
		
		
		
	}

}
