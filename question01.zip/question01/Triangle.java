package com.java.question01;

import java.util.Scanner;

public class Triangle implements Shape {
	Scanner sc = new Scanner(System.in);
	@Override
	public double area() {
		System.out.println("To calculate area of triangle");
		System.out.print("Enter Base of tringle : ");
		int b = sc.nextInt();
		System.out.print("Enter Height of tringle : ");
		int h = sc.nextInt();
		double s = 0.5*Math.PI*b*h;
		return s;
	}

	@Override
	public double perimeter() {
		System.out.println("To calculate perimeter of triangle");
		System.out.print("Enter 1st side of tringle : ");
		int s1 = sc.nextInt();
		System.out.print("Enter 2nd side of tringle : ");
		int s2 = sc.nextInt();
		System.out.print("Enter 3rd side of tringle : ");
		int s3 = sc.nextInt();
		double s = s1+s2+s3;
		return s;
	}

}
