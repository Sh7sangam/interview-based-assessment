package com.java.question01;

public class CalculateMain {

	public static void main(String[] args) {

		Shape circle = new Circle();
		double area = circle.area();
		System.out.println("This is area of cirlce : "+area);
		double perimeter = circle.perimeter();
		System.out.println("This is Perimeter of cirlce : "+perimeter);
		
		Shape triangle = new Triangle();
		double area1 = triangle.area();
		System.out.println("This is area of cirlce : "+area1);
		double perimeter1 = triangle.perimeter();
		System.out.println("This is Perimeter of cirlce : "+perimeter1);
		
	}

}
