package com.java.question01;

public interface Shape {
	
	public double area();
	public double perimeter();
}
