package com.java.question01;

import java.util.Scanner;

public class Rectangle implements Shape {
	Scanner sc = new Scanner(System.in);
	@Override
	public double area() {
		System.out.print("Enter length of Reactangle : ");
		int b = sc.nextInt();
		System.out.print("Enter width of Reactangle : ");
		int h = sc.nextInt();
		double s = b*h;
		return s;
	}

	@Override
	public double perimeter() {
		System.out.print("Enter length of Reactangle : ");
		int b = sc.nextInt();
		System.out.print("Enter width of Reactangle : ");
		int h = sc.nextInt();
		double s =2* (b+h);
		return s;
	}

}
