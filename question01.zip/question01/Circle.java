package com.java.question01;

import java.util.Scanner;

public class Circle implements Shape {
	
	Scanner sc =new Scanner(System.in);
	@Override
	public double area() {
		System.out.println("To calculate area of circle");
		System.out.print("Enter radius of circle : ");
		int r = sc.nextInt();
		double s = Math.PI*r*r;
		return s;
	}

	@Override
	public double perimeter() {
		System.out.println("To calculate perimeter of circle");
		System.out.print("Enter radius of circle : ");
		int r = sc.nextInt();
		double s = 2*Math.PI*r;
		return s;
	}

}
