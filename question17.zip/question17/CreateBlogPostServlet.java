package com.java.question17;
import com.example.blog.models.BlogPost;
import com.example.blog.models.BlogPostDAO;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

public class CreateBlogPostServlet extends HttpServlet {
    private BlogPostDAO blogPostDAO;

    @Override
    public void init() throws ServletException {
        // Initialize the DAO with the database connection
        // Here, you can establish the database connection using JDBC or a connection pool
        // For simplicity, let's assume you have a connection object called "connection"
        blogPostDAO = new BlogPostDAO(connection);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String content = request.getParameter("content");

        BlogPost blogPost = new BlogPost();
        blogPost.setTitle(title);
        blogPost.setDescription(description);
        blogPost.setContent(content);

        try {
            // Insert the blog post into the database
            blogPostDAO.insertBlogPost(blogPost);
            response.sendRedirect(request.getContextPath() + "/blogposts");
        } catch (SQLException e) {
            // Handle any exceptions appropriately
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}