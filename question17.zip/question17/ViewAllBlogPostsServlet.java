package com.java.question17;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class ViewAllBlogPostsServlet extends HttpServlet {
    private BlogPostDAO blogPostDAO;

    @Override
    public void init() throws ServletException {
        // Initialize the DAO with the database connection
        // Here, you can establish the database connection using JDBC or a connection pool
        // For simplicity, let's assume you have a connection object called "connection"
        blogPostDAO = new BlogPostDAO(connection);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Retrieve all blog posts from the database
            List<BlogPost> blogPosts = blogPostDAO.getAllBlogPosts();

            // Forward the blog post data to a JSP for display
            request.setAttribute("blogPosts", blogPosts);
            request.getRequestDispatcher("/WEB-INF/views/viewAllBlogPosts.jsp").forward(request, response);
        } catch (SQLException e) {
            // Handle any exceptions appropriately
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
