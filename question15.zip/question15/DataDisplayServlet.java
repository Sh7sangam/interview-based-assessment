package com.java.question15;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DataDisplayServlet extends HttpServlet {
    private static final String url = "jdbc:mysql://localhost:3306/mydatabase"; // Replace "mydatabase" with your database name
    private static final String username = "your-username"; // Replace with your MySQL username
    private static final String password = "your-password"; // Replace with your MySQL password

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement()) {

            String query = "SELECT * FROM mytable"; // Replace "mytable" with your table name
            ResultSet resultSet = statement.executeQuery(query);

            out.println("<html><body>");
            out.println("<table border='1'>");
            out.println("<tr><th>ID</th><th>Name</th><th>Age</th></tr>");

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");

                out.println("<tr><td>" + id + "</td><td>" + name + "</td><td>" + age + "</td></tr>");
            }

            out.println("</table>");
            out.println("</body></html>");

            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}