package com.java.question04;

import java.util.Scanner;

public class BankRunnable {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		BankAccount ba = new BankAccount();
		while (true) {
			System.out.println("1: to deposit money");
			System.out.println("2: to Withdraw money");
			System.out.println("3: to Check Balance money");
			System.out.println("4: to Exit money");
			System.out.print("Enter valid number : ");
			int n = sc.nextInt();
			switch (n) {
			case 1:
				ba.deposit();
				break;

			case 2:
				ba.withdraw();
				break;

			case 3:
				ba.checkBalance();
				break;
			
			case 4:
				System.out.println("Exit");
				System.exit(n);
				break;
			default :
				System.out.println("Invalid Integer pressed");
			
			}
		}
	}

}
