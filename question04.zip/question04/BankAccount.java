package com.java.question04;

import java.util.Scanner;

public class BankAccount {
	Scanner sc =new Scanner(System.in);
	int balance;
	public int deposit() {
		System.out.println("Enter amount to deposit");
		int a = sc.nextInt();
		balance = balance + a;
		System.out.println("Amount deposited successfully "+a);
		return balance;
	}
	public int withdraw() {
		System.out.println("Enter amount to withdraw");
		int w = sc.nextInt();
		if(w<balance) {
			System.out.println("Amout successfully withdraw "+ w);
			balance = balance - w;
			return  balance;
		}
		else
			System.out.println("Insufficient balance");
		return balance;
		
	}
	public void checkBalance() {
		System.out.println("Available balance : "+balance);
		
	}

}
