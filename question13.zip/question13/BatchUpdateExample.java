package com.java.question13;
import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BatchUpdateExample {
    private static final String url = "jdbc:postgresql://localhost:5432/ineuron"; // Replace "mydatabase" with your database name
    private static final String username = "root"; // Replace with your PostgreSQL username
    private static final String password = "123456"; // Replace with your PostgreSQL password

    public static void main(String[] args) {
        String filePath = "data.txt"; // Replace with your input file path

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            // Enable batch processing
            connection.setAutoCommit(false);

            // Create a prepared statement with batch updates
            String query = "INSERT INTO mytable (name, age) VALUES (?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                BufferedReader reader = new BufferedReader(new FileReader(filePath));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] data = line.split(",");
                    String name = data[0];
                    int age = Integer.parseInt(data[1]);

                    // Add parameters to the batch
                    statement.setString(1, name);
                    statement.setInt(2, age);
                    statement.addBatch();
                }

                // Execute the batch update
                int[] updateCounts = statement.executeBatch();

                // Commit the transaction
                connection.commit();

                System.out.println("Batch update executed successfully. Rows affected: " + updateCounts.length);
            } catch (Exception e) {
                // Rollback the transaction in case of an exception
                connection.rollback();
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}