package csi.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;


public class JdbcUtil {
	
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getJdbcConnection() throws SQLException, IOException {
		FileInputStream fis = new FileInputStream("D:\\workBench\\JdbcCrudApp\\src\\csi\\properties\\application.properties");
		Properties properties = new Properties();
		properties.load(fis);
		
		Connection connection = DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("username"),
				properties.getProperty("password"));
		return connection;
	}
	
	public static void cleanUp(Connection con,	Statement stm,ResultSet resultset) throws SQLException	{
		if(con !=null)
			con.close();
		if(stm !=null)
			stm.close();
		if (resultset != null) 
			resultset.close();

	}

}
