package csi.persistance;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import csi.dto.Student;
import csi.util.JdbcUtil;

public class StudentDaoImpl implements IStudentDao {
	Connection connection = null;
	PreparedStatement pstm = null;
	ResultSet resultset = null;

	@Override
	public String addStudent(String sname, Integer sage, String sAddress) {

		String sqlQuery = "insert into student (`name`,`age`,`address`)values(?,?,?)";

		try {
			connection = JdbcUtil.getJdbcConnection();

			if (connection != null) {
				pstm = connection.prepareStatement(sqlQuery);
			}
			if (pstm != null) {
				pstm.setString(1, sname);
				pstm.setInt(2, sage);
				pstm.setString(3, sAddress);

				int rowaffected = pstm.executeUpdate();

				if (rowaffected == 1) {
					return "success";
				}
			}

		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "failure";
	}

	@Override
	public Student searchStudent(Integer sid) {
		Student std =null;

		String sqlSelectQuery = "select id,name,age,address from student where id = ?";

		try {
			connection = JdbcUtil.getJdbcConnection();

			if (connection != null) {
				pstm = connection.prepareStatement(sqlSelectQuery);
			}
			if (pstm != null) {
				pstm.setInt(1, sid);
				
				resultset = pstm.executeQuery();
			}
			if (resultset!=null)
				if (resultset.next()) {
					std = new Student();
					std.setSid(resultset.getInt(1));
					std.setSname(resultset.getString(2));
					std.setSage(resultset.getInt(3));
					std.setSaddress(resultset.getString(4));
					
					return std;
				}
			

		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return std;
	}

	@Override
	public String updateStudent(Integer sid, String sname, Integer sage, String saddress) {
		return null;
	}

	@Override
	public String deleteStudent(Integer sid) {
		String sqlQuery = "delete from student where id = ?";

		try {
			connection = JdbcUtil.getJdbcConnection();

			if (connection != null) {
				pstm = connection.prepareStatement(sqlQuery);
			}
			if (pstm != null) {
				pstm.setInt(1, sid);

				int rowaffected = pstm.executeUpdate();

				if (rowaffected == 1) {
					return "success";
				}else
					return "Not found";
			}

		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "failure";
	}

}
