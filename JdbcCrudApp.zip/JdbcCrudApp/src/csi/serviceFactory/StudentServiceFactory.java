package csi.serviceFactory;

import csi.service.StudentServiceImpl;

//AbStraction logic of implementation
public class StudentServiceFactory {

	private StudentServiceFactory() {}
	
	private static StudentServiceImpl studentService=null;
	
	public static StudentServiceImpl getStudentServiceFactory() {
		if(studentService==null)
			studentService= new StudentServiceImpl();
		return studentService;
	}
}
