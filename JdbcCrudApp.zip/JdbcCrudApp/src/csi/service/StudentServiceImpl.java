package csi.service;

import csi.DaoFactory.StudentDaoFactory;
import csi.dto.Student;
import csi.persistance.IStudentDao;

public class StudentServiceImpl implements IStudentService {
	

	IStudentDao studentDao =null;
	@Override
	public String addStudent(String sname, Integer sage, String sAddress) {
		
		studentDao =StudentDaoFactory.getStudentDao();
		
		return studentDao.addStudent(sname, sage, sAddress);
	}

	@Override
	public Student searchStudent(Integer sid) {
		studentDao =StudentDaoFactory.getStudentDao();
		return studentDao.searchStudent(sid);
	}

	@Override
	public String updateStudent(Integer sid, String sname, Integer sage, String saddress) {
		return null;
	}

	@Override
	public String deleteStudent(Integer sid) {
		studentDao =StudentDaoFactory.getStudentDao();
		return studentDao.deleteStudent(sid);
	}

}
