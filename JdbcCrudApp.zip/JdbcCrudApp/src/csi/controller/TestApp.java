package csi.controller;

import java.util.Scanner;

import csi.dto.Student;
import csi.service.IStudentService;
import csi.serviceFactory.StudentServiceFactory;

public class TestApp {

	public static void main(String[] args) {
	
		//insertOperation();
		//searchOperation();
		deleteOperation();
		
		
	}

	private static void deleteOperation() {
		IStudentService studentService = StudentServiceFactory.getStudentServiceFactory();
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter Student id : ");
		Integer sid =scanner.nextInt();
		
		String deleteStudent = studentService.deleteStudent(sid);
		if (deleteStudent.equalsIgnoreCase("success")) {
			System.out.println("Record Deleted successfully");
		} else {
			System.out.println("ID not Available : "+sid);
		}
	}

	private static void searchOperation() {
		IStudentService studentService = StudentServiceFactory.getStudentServiceFactory();
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Student id : ");
		int sid = scanner.nextInt();
		Student std = studentService.searchStudent(sid);
		if (std != null) {
			System.out.println(std);
			System.out.println("ID\tName\tAddress\tAge");
			System.out.println(std.getSid()+"\t"+std.getSname()+"\t"+std.getSaddress()+"\t"+std.getSage());
			
		}else
			System.out.println("Record not found : "+ sid);
	}

	private static void insertOperation() {
		IStudentService studentService = StudentServiceFactory.getStudentServiceFactory();
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter Student name : ");
		
		String sname= scanner.next();
		System.out.print("Enter Student age : ");
		Integer sage =scanner.nextInt();
		System.out.print("Enter Student address : ");
		String saddre = scanner.next();
		
		String addStudent = studentService.addStudent(sname, sage, saddre);
		if (addStudent.equalsIgnoreCase("success")) {
			System.out.println("Record added successfully");
		} else {
			System.out.println("Record not added ");
		}
	}

}
