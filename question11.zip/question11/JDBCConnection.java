package com.java.question11;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class JDBCConnection {

	public static void main(String[] args) throws Exception {

		//1. Load and register the driver
		Class<?> forName = Class.forName("com.mysql.cj.jdbc.Driver");
		//2. Established the connection between database
		String url ="jdbc:mysql://localhost:3306/ineuron";
		//Username and password
		String username = "root";
		String password = "123456";
		
		Connection connection = DriverManager.getConnection(url, username, password);
		
		//3. Create Statement object and then send Query 
		String query = "select sid,saddress,sage,sname from Student";
		
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery(query);
		System.out.println();
		System.out.println("SID\tSNAME\tSAGE\tSADDRESS");
		
		//4. Process the resultSet
		while (resultSet.next())
		{
		Integer sid = resultSet.getInt(1);
		String saddr = resultSet.getString(2);
		Integer sage = resultSet.getInt(3);
		String sname = resultSet.getString(4);
		System.out.println(sid+"\t"+sname+"\t"+sage+"\t"+saddr);
		}
		
	}

}